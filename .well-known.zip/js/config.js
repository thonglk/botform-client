angular.module('starter.configs', [])
    .constant("CONFIG", {
        'UpdateAt': "2017-04-10T04:44:21.253Z",
        'Location': true,
        "WEBURL": 'https://botform.me',
        "APIURL": 'https://botform-webserver.herokuapp.com',
        "AnaURL": 'http://localhost:8081',
        'FCM_KEY': "AAAArk3qIB4:APA91bEWFyuKiFqLt4UIrjUxLbduQCWJB4ACptTtgAovz4CKrMdonsS3jt06cfD9gGOQr3qtymBmKrsHSzGhqyJ_UWrrEbA4YheznlqYjsCBp_12bNPFSBepqg_qrxwdYxX_IcT9ne5z6s02I2mu2boy3VTN3lGPYg",
        "APIKey": 'AIzaSyATOX9rL_ULV-Q_e2kImu9wYgK2AToOteQ'
    });
