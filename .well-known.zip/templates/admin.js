"use strict";


app
    .controller('ladibotCtrl', function (AuthUser, $stateParams, $state, $scope, $rootScope, $timeout, CONFIG, $http, toastr) {
        $rootScope.myState = 'viewBot'

        console.log('$stateParams.page', $stateParams.page)
        if ($stateParams.page) {
            $rootScope.pageID = $stateParams.page
            window.localStorage.setItem('pageID', $stateParams.page)
        }
        $scope.query = {page: $rootScope.pageID}
        $rootScope.loadResponse($scope.query)
        $scope.setIDpage = function (card) {
            $rootScope.pageID = card.id
            $scope.query = {page: $rootScope.pageID}
            $rootScope.loadResponse($scope.query)

        }

    })

    .controller('createCtrl', function (AuthUser, $stateParams, $state, $scope, $rootScope, $timeout, CONFIG, $http, toastr) {
        $scope.viewLink = ''
        if ($stateParams.page != 'null') {
            $scope.pageID = $stateParams.page
            window.localStorage.setItem('pageID', $stateParams.page)
        }

        $rootScope.setPage = function (card) {
            $scope.card = card

        }


        $scope.state = $stateParams.id
        console.log('$scope.state', $scope.state)
        $scope.chatBot = {}

        $scope.buildBot = function (url) {
            $scope.loading = true
            var card = $scope.card
            $rootScope.service.JoboApi('getchat', {
                pageID: card.id,
                access_token: card.access_token,
                name: card.name,
                url: url
            }).then(function successCallback(response) {
                $scope.loading = false

                console.log('response', response)
                $timeout(function () {
                    $scope.chatBot = response.data
                    $scope.viewLink = `https://m.me/${card.id}`
                })
                window.localStorage.setItem('pageID', card.id)
                $rootScope.pageID = card.id
            }, function (error) {
                console.log('error', error)
                toastr.error(error)
            })
        }


    })
    .controller('rebrandCtrl', function (AuthUser, $stateParams, $state, $scope, $rootScope, $timeout, CONFIG, $http, toastr) {
        if ($stateParams.page != 'null') {
            $scope.pageID = $stateParams.page
            window.localStorage.setItem('pageID', $stateParams.page)
        }

        $rootScope.removeBranding = function (card) {
            $rootScope.loading = true

            $scope.card = card
            $rootScope.service.JoboApi('removeChatfuelBranding', {
                pageID: card.id,
            }).then(function successCallback(response) {
                $rootScope.loading = false
                toastr.success(response.data)
                console.log('response', response)
            }, function (error) {
                console.log('error', error)
                toastr.error(error)
            })
        }



    })


